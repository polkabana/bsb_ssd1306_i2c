var searchData=
[
  ['initcmds',['initcmds',['../struct_dev_type.html#adb1a2fe45c58f002fe4e535f4dc4c57e',1,'DevType']]],
  ['initsize',['initSize',['../struct_dev_type.html#a0c7a0aae17eedda9252d9e777605a245',1,'DevType']]]
];
